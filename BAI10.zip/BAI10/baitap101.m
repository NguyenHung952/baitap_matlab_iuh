clc; clear; close all;

% Khai báo số mẫu của bộ lọc FIR
N = 51; % Độ dài bộ lọc FIR
fc = 3000; % Tần số cắt (Hz)
fs = 48000; % Tần số lấy mẫu (Hz)

% Tạo hệ số bộ lọc FIR thông thấp bằng cửa sổ Hamming
h = fir1(N-1, 2*fc/fs, 'low', hamming(N));

% Hiển thị hệ số lọc
figure;
stem(h);
title('Hệ số bộ lọc FIR');
xlabel('Mẫu (n)');
ylabel('h(n)');

% Tạo tín hiệu đầu vào - xung đơn (impulse)
x = [1, zeros(1, 199)]; % Tín hiệu có một xung tại n=0

% Áp dụng bộ lọc FIR bằng phép tích chập
y = conv(x, h);

% Hiển thị đáp ứng xung
figure;
plot(y, 'b', 'LineWidth', 1.5);
title('Đáp ứng xung của bộ lọc FIR');
xlabel('Mẫu (n)');
ylabel('y(n)');
grid on;

% Kiểm tra đáp ứng tần số của bộ lọc
H = fft(h, 1024); % FFT để kiểm tra tần số
f = linspace(0, fs/2, 512); % Trục tần số (Hz)

figure;
plot(f, abs(H(1:512)), 'r', 'LineWidth', 1.5);
title('Đáp ứng biên độ của bộ lọc FIR');
xlabel('Tần số (Hz)');
ylabel('|H(f)|');
grid on;


