%BAI 11.3
clear all; clc;

%% 1. Thiết kế FIR thông dải
Fs = 16000;                % Tần số lấy mẫu (16 kHz)
f_center = 4000;           % Tần số trung tâm (4 kHz)
BW = 3000;                 % Băng thông (3 kHz)
N = 256;                   % Số hệ số FIR (bậc lọc)

% Tính tần số cắt thấp và cao
f_low = f_center - BW / 2;  % Tần số cắt thấp (2.5 kHz)
f_high = f_center + BW / 2; % Tần số cắt cao (5.5 kHz)

% Chuẩn hóa tần số cắt theo Nyquist (Fs/2)
Wn = [f_low, f_high] / (Fs / 2);

% Thiết kế FIR thông dải bằng cửa sổ Hamming
h = fir1(N, Wn, 'bandpass', hamming(N + 1));

% Hiển thị đáp ứng tần số của bộ lọc FIR
figure;
freqz(h, 1, 1024, Fs);
title('Đáp ứng tần số của FIR thông dải');

%% 2. Tạo tín hiệu sóng tam giác từ máy phát hàm
duration = 2;                   % 2 giây
t = (0:1/Fs:duration-1/Fs);     % Vector thời gian
triangle_wave = sawtooth(2 * pi * 1000 * t, 0.5); % Sóng tam giác tần số 1 kHz

%% 3. Lưu tín hiệu vào file
triangle_wave_short = int16(triangle_wave * 1000); % Chuẩn hóa tín hiệu
L = length(triangle_wave_short);
fid = fopen('triangle_wave_record.h', 'w');
fprintf(fid, '#define SPEECHBUF %d\n', L);
fprintf(fid, 'short TriangleWave[SPEECHBUF+1] = {\n');
fprintf(fid, '%d, ', triangle_wave_short(1:end-1));
fprintf(fid, '%d};\n', triangle_wave_short(end));
fclose(fid);
disp('Tín hiệu sóng tam giác đã được lưu vào triangle_wave_record.h.');

%% 4. Lọc tín hiệu qua FIR
y = filter(h, 1, triangle_wave);

%% 5. Tính phổ tín hiệu
% Phổ tín hiệu gốc
X = fft(triangle_wave);
X = abs(X(1:floor(length(X)/2)));  % Phổ biên độ
f = (0:length(X)-1) * (Fs / length(triangle_wave) / 2);

% Phổ tín hiệu sau lọc
Y = fft(y);
Y = abs(Y(1:floor(length(Y)/2)));

%% 6. Hiển thị phổ tín hiệu
figure;
subplot(2, 1, 1);
plot(f, X, 'b');
title('Phổ tín hiệu gốc (sóng tam giác)');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

subplot(2, 1, 2);
plot(f, Y, 'r');
title('Phổ tín hiệu sau lọc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

%% 7. Lưu hệ số FIR vào file để thực thi trên KIT DSP
h_short = int16(h * 32767);  % Quy đổi về số nguyên 16-bit
fid = fopen('fir_coefficients.h', 'w');
fprintf(fid, '#define N %d\n', N);
fprintf(fid, 'short h[N+1] = {\n');
fprintf(fid, '%d, ', h_short(1:end-1));
fprintf(fid, '%d};\n', h_short(end));
fclose(fid);
disp('Hệ số FIR đã được lưu vào fir_coefficients.h.');

%% 8. Ghi tín hiệu đã lọc ra file .wav
audiowrite('filtered_signal.wav', y, Fs);
disp('Tín hiệu đã lọc được lưu vào filtered_signal.wav.');