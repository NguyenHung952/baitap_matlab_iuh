%VIDU11.2
clear all; 
N = 100; 
cutoff = 0.068; % Tần số cắt chuẩn hóa (0.068 ≈ 3kHz với Fs=44kHz)

% Thiết kế bộ lọc FIR với hàm fir1
b = fir1(N, cutoff); 
freqz(b, 1); % Hiển thị đáp ứng tần số của bộ lọc
b_short = int16(b * 32767); % Chuẩn hóa hệ số lọc để lưu file

% Ghi hệ số bộ lọc vào file filter_coefficients.h
fid = fopen('filter_coefficients.h', 'w');
fprintf(fid, '#define N %d\n', N);
fprintf(fid, 'short h[N+1] = {\n');
fprintf(fid, '%d, ', b_short(1:end-1));
fprintf(fid, '%d};\n', b_short(end));
fclose(fid);

% Thu âm tín hiệu (2 giây, 44.1kHz, 16-bit, 1 kênh)
recorder = audiorecorder(44100, 16, 1);
recordblocking(recorder, 2);
audioarray = getaudiodata(recorder);
b_short = int16(audioarray * 1000); % Chuẩn hóa tín hiệu âm thanh

% Ghi tín hiệu âm thanh vào file audiorecord.h
L = length(audioarray);
fid = fopen('audiorecord.h', 'w');
fprintf(fid, '#define SPEECHBUF %d\n', L);
fprintf(fid, 'short Speech[SPEECHBUF+1] = {\n');
fprintf(fid, '%d, ', b_short(1:end-1));
fprintf(fid, '%d};\n', b_short(end));
fclose(fid);