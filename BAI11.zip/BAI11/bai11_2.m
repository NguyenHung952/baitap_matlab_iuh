%BAI 11.2
clear all; clc;

%% 1. Thiết kế FIR thông dải
Fs = 16000;                % Tần số lấy mẫu (16 kHz)
f_center = 4000;           % Tần số trung tâm (4 kHz)
BW = 3000;                 % Băng thông (3 kHz)
N = 256;                   % Số hệ số FIR (bậc lọc)

% Tính tần số cắt thấp và cao
f_low = f_center - BW / 2;  % Tần số cắt thấp (2.5 kHz)
f_high = f_center + BW / 2; % Tần số cắt cao (5.5 kHz)

% Chuẩn hóa tần số cắt theo Nyquist (Fs/2)
Wn = [f_low, f_high] / (Fs / 2);

% Thiết kế FIR thông dải bằng cửa sổ Hamming
h = fir1(N, Wn, 'bandpass', hamming(N + 1));

% Hiển thị đáp ứng tần số của bộ lọc
figure;
freqz(h, 1, 1024, Fs);
title('Đáp ứng tần số của FIR thông dải');

%% 2. Thu âm tín hiệu từ micro trong 2 giây
recorder = audiorecorder(Fs, 16, 1);  % Tần số lấy mẫu 16 kHz, 16-bit, 1 kênh
disp('Bắt đầu thu âm...');
recordblocking(recorder, 2);          % Thu tín hiệu trong 2 giây
disp('Hoàn tất thu âm.');
audio = getaudiodata(recorder);

%% 3. Lưu tín hiệu vào file
audio_short = int16(audio * 1000);    % Chuẩn hóa dữ liệu để lưu
L = length(audio_short);
fid = fopen('audio.record.h', 'w');
fprintf(fid, '#define SPEECHBUF %d\n', L);
fprintf(fid, 'short Speech[SPEECHBUF+1] = {\n');
fprintf(fid, '%d, ', audio_short(1:end-1));
fprintf(fid, '%d};\n', audio_short(end));
fclose(fid);
disp('Tín hiệu âm thanh đã được lưu vào audio.record.h.');

%% 4. Lọc tín hiệu qua FIR
y = filter(h, 1, audio);

%% 5. Tính phổ tín hiệu
% Phổ tín hiệu gốc
X = fft(audio);
X = abs(X(1:floor(length(X)/2)));  % Phổ biên độ
f = (0:length(X)-1) * (Fs / length(audio) / 2);

% Phổ tín hiệu sau lọc
Y = fft(y);
Y = abs(Y(1:floor(length(Y)/2)));

%% 6. Hiển thị phổ tín hiệu
figure;
subplot(2, 1, 1);
plot(f, X, 'b');
title('Phổ tín hiệu gốc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

subplot(2, 1, 2);
plot(f, Y, 'r');
title('Phổ tín hiệu sau lọc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

%% 7. Ghi tín hiệu đã lọc ra file .wav
audiowrite('filtered_signal.wav', y, Fs);
disp('Tín hiệu đã lọc được lưu vào filtered_signal.wav.');