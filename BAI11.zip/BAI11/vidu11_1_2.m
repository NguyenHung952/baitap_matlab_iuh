clear all; N=100;cutoff=0.2;
b=firl(N,cutoff); freqz(b,1);b_short=int16(b*32767);
fid=fopen('filter_coefficients.h','w'); fprintf(fid,'#define N%d',N);
fprintf(fid,'\n');fprintf(fid,'short h[N+1]={\n');
fprintf(fid,'%d,',b_short(1:end-1));fprintf(fid,'%d};\n',b_short(end)); 
fclose(fid);