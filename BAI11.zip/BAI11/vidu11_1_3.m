% VI DU 11.1
clear all; clc;

% Tần số lấy mẫu
Fs = 44000;  % 44 kHz

% Đọc hệ số lọc FIR từ file lp1500_256.cof
N = 256;  % Số hệ số FIR
h = [
0,
-0,
-1,
-1,
-1,
-1,
-2,
-2,
-2,
-2,
-2,
-2,
-2,
-1,
-1,
-0,
0,
1,
2,
2,
3,
4,
4,
5,
5,
5,
5,
5,
4,
3,
2,
1,
-1,
-2,
-4,
-6,
-7,
-9,
-10,
-11,
-11,
-11,
-11,
-10,
-8,
-6,
-4,
-1,
2,
5,
8,
11,
14,
16,
19,
20,
21,
21,
20,
18,
15,
12,
8,
3,
-3,
-8,
-14,
-20,
-25,
-29,
-33,
-35,
-37,
-37,
-35,
-32,
-27,
-21,
-13,
-5,
5,
15,
25,
34,
43,
51,
58,
62,
64,
64,
62,
56,
48,
37,
24,
8,
-9,
-27,
-45,
-63,
-81,
-96,
-109,
-119,
-125,
-126,
-123,
-113,
-98,
-77,
-51,
-18,
19,
62,
108,
158,
210,
264,
317,
369,
419,
466,
509,
546,
576,
600,
616,
624,
624,
616,
600,
576,
546,
509,
466,
419,
369,
317,
264,
210,
158,
108,
62,
19,
-18,
-51,
-77,
-98,
-113,
-123,
-126,
-125,
-119,
-109,
-96,
-81,
-63,
-45,
-27,
-9,
8,
24,
37,
48,
56,
62,
64,
64,
62,
58,
51,
43,
34,
25,
15,
5,
-5,
-13,
-21,
-27,
-32,
-35,
-37,
-37,
-35,
-33,
-29,
-25,
-20,
-14,
-8,
-3,
3,
8,
12,
15,
18,
20,
21,
21,
20,
19,
16,
14,
11,
8,
5,
2,
-1,
-4,
-6,
-8,
-10,
-11,
-11,
-11,
-11,
-10,
-9,
-7,
-6,
-4,
-2,
-1,
1,
2,
3,
4,
5,
5,
5,
5,
5,
4,
4,
3,
2,
2,
1,
0,
-0,
-1,
-1,
-2,
-2,
-2,
-2,
-2,
-2,
-2,
-1,
-1,
-1,
-1,
-0,
-0];  
% Nhập hệ số FIR ở đây (các giá trị của h như đã cung cấp)

% Kiểm tra kích thước hệ số lọc
if length(h) ~= N
    error('Số lượng hệ số lọc không khớp với N = %d.', N);
end

% Tạo tín hiệu âm thanh giả lập
duration = 2;  % 2 giây
samples = Fs * duration;  % Số mẫu
t = (0:samples-1) / Fs;  % Vector thời gian
x = sin(2 * pi * 500 * t) + 0.5 * sin(2 * pi * 1500 * t);  % Tín hiệu âm thanh (500Hz và 1500Hz)

% Thực hiện lọc FIR
y = zeros(size(x));  % Mảng để lưu tín hiệu đã lọc
dly = zeros(N, 1);   % Bộ đệm trễ cho FIR

for n = 1:length(x)
    dly(1) = x(n);             % Cập nhật mẫu mới nhất vào bộ đệm
    y(n) = sum(h .* dly);      % Tích chập FIR (convolution)
    dly(2:end) = dly(1:end-1); % Dịch bộ đệm trễ
end

% Chuẩn hóa kết quả
y = y / max(abs(y));

% Tạo phổ tín hiệu gốc
X = fft(x);
X = abs(X(1:length(X)/2));  % Lấy phổ biên độ
f = (0:length(X)-1) * (Fs / length(x) / 2);  % Trục tần số

% Tạo phổ tín hiệu đã lọc
Y = fft(y);
Y = abs(Y(1:length(Y)/2));  % Lấy phổ biên độ

% Đáp ứng tần số của bộ lọc FIR
[H, Freq] = freqz(h, 1, 1024, Fs);

% Vẽ đồ thị
figure;

% Tín hiệu gốc và tín hiệu đã lọc
subplot(3,1,1);
plot(t, x);
title('Tín hiệu gốc (trước lọc)');
xlabel('Thời gian (s)');
ylabel('Biên độ');

subplot(3,1,2);
plot(t, y);
title('Tín hiệu đã lọc (sau FIR)');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Phổ tín hiệu gốc và tín hiệu đã lọc
figure;
subplot(2,1,1);
plot(f, X);
title('Phổ tín hiệu gốc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

subplot(2,1,2);
plot(f, Y);
title('Phổ tín hiệu đã lọc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

% Đáp ứng tần số của bộ lọc FIR
figure;
plot(Freq, abs(H));
title('Đáp ứng tần số của bộ lọc FIR');
xlabel('Tần số (Hz)');
ylabel('Biên độ');
grid on;

% Ghi tín hiệu đã lọc ra file âm thanh
audiowrite('filtered_signal.wav', y, Fs);
disp('Tín hiệu đã lọc được lưu vào file filtered_signal.wav.');