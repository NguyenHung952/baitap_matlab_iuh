clear all; 
Fs = 44000; % Tần số lấy mẫu

filename = 'nhac.mp3'; % Tên file âm thanh

samples = [1, 10 * Fs]; % Đọc 10 giây đầu tiên của file

clear y Fs; % Xóa các biến trước đó

% Đọc dữ liệu âm thanh từ file
[y, Fs] = audioread(filename, samples);

y = y(:, 1); % Chỉ lấy kênh thứ nhất (mono nếu stereo)
L0 = length(y); 
y0 = y; % Sao chép dữ liệu

% Lấy phần cuối 1 giây của tín hiệu (44,000 mẫu)
y1 = y0(L0 - 44000 + 1:L0);

% Chuyển đổi dữ liệu sang int16 và chuẩn hóa
b_short = int16(y1 * 1000);%32767

% Xác định độ dài dữ liệu
L = length(y1);

% Ghi dữ liệu ra file audiorecord.h
fid = fopen('audiorecord.h', 'w'); % Mở file để ghi
fprintf(fid, '#define SPEECHBUF %d\n', L); % Định nghĩa kích thước bộ đệm
fprintf(fid, 'short Speech[SPEECHBUF+1] = {\n'); % Khai báo mảng dữ liệu
fprintf(fid, '%d, ', b_short(1:end-1)); % Ghi từng phần tử (trừ phần tử cuối)
fprintf(fid, '%d};\n', b_short(end)); % Ghi phần tử cuối cùng và kết thúc mảng
fclose(fid); % Đóng file