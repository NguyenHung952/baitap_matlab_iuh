%BAI11.1
clear all; clc;

% Thông số thiết kế
Fs = 32000;               % Tần số lấy mẫu (32 kHz)
N = 256;                  % Số hệ số FIR

% Hệ số FIR thông dải từ lp3000.h
h = [-3, -3, -3, -4, -3, -2, 1, 5, 11, 20, 30, 42, 56, 69, 82, 94, 103, 108, 110, ...
    106, 98, 85, 69, 49, 28, 7, -12, -29, -40, -47, -48, -44, -35, -23, -9, 6, ...
    19, 29, 35, 37, 34, 27, 16, 5, -7, -18, -26, -30, -30, -27, -19, -9, 1, ...
    12, 20, 26, 28, 26, 21, 12, 2, -8, -17, -24, -27, -26, -21, -14, -5, 6, ...
    15, 22, 26, 26, 23, 16, 6, -4, -13, -21, -26, -27, -24, -17, -8, 2, 12, ...
    21, 26, 28, 26, 19, 10, -1, -12, -21, -27, -30, -28, -22, -12, -1, 11, ...
    21, 28, 32, 30, 24, 15, 3, -10, -21, -30, -34, -33, -27, -17, -5, 9, ...
    21, 31, 36, 36, 30, 20, 7, -8, -21, -32, -39, -39, -34, -24, -9, 6, ...
    22, 34, 41, 43, 38, 27, 12, -5, -21, -35, -44, -47, -42, -31, -16, 3, ...
    21, 37, 47, 51, 47, 36, 19, 0, -21, -38, -51, -55, -52, -41, -24, -2, ...
    20, 40, 54, 60, 58, 47, 29, 5, -19, -41, -58, -66, -64, -53, -34, -9, ...
    18, 43, 62, 72, 72, 61, 40, 13, -16, -44, -66, -78, -80, -69, -47, -18, ...
    14, 45, 70, 86, 89, 78, 56, 25, -11, -46, -75, -94, -99, -89, -66, -32, ...
    8, 48, 81, 103, 111, 102, 77, 40, -4, -49, -87, -114, -125, -117, -91, ...
    -51, -1, 50, 95, 127, 141, 135, 108, 63, 8, -50, -103, -143, -162, -157, ...
    -129, -80, -17, 51, 114, 162, 188, 186, 156, 101, 28] / 32767;  % Normalized

% Đọc tín hiệu từ file nhạc
[audio, Fs_audio] = audioread('nhac.mp3');
audio = audio(:, 1);            % Lấy kênh mono nếu tín hiệu stereo
audio = resample(audio, Fs, Fs_audio);  % Nội suy về Fs (32kHz)
audio = audio(1:Fs*2);          % Lấy 2 giây đầu tiên

% Lọc tín hiệu qua FIR
y = filter(h, 1, audio);

% Phổ tín hiệu gốc
X = fft(audio);
X = abs(X(1:floor(length(X)/2)));  % Phổ biên độ
f = (0:length(X)-1) * (Fs / length(audio) / 2);

% Phổ tín hiệu đã lọc
Y = fft(y);
Y = abs(Y(1:floor(length(Y)/2)));

% Đáp ứng tần số của FIR
[H, Freq] = freqz(h, 1, 1024, Fs);

% Hiển thị kết quả
figure;

% Tín hiệu gốc và tín hiệu đã lọc
subplot(3,1,1);
plot(audio);
title('Tín hiệu gốc');
xlabel('Thời gian (s)');
ylabel('Biên độ');

subplot(3,1,2);
plot(y);
title('Tín hiệu sau lọc FIR');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Phổ tín hiệu trước và sau lọc
figure;
subplot(2,1,1);
plot(f, X, 'b');
title('Phổ tín hiệu gốc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

subplot(2,1,2);
plot(f, Y, 'r');
title('Phổ tín hiệu sau lọc');
xlabel('Tần số (Hz)');
ylabel('Biên độ');

% Đáp ứng tần số của FIR
figure;
plot(Freq, abs(H));
title('Đáp ứng tần số của bộ lọc FIR');
xlabel('Tần số (Hz)');
ylabel('Biên độ');
grid on;

% Ghi tín hiệu đã lọc ra file .wav
audiowrite('filtered_signal.wav', y, Fs);
disp('Tín hiệu đã lọc được lưu vào filtered_signal.wav.');