n=[-200:200]; x=2*[sin(0.01*pi*n).*cos(0.5*pi*n)];
figure; subplot(1,2,1); stem(n,x); title('Squence in Problem 2.1F')
xlabel('n'); ylabel('x(n)');