
function [y,n] =gap_tinhieu(x,n)
y=fliplr(x);n=-fliplr(n);
end
