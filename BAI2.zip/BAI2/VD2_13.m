clc
clear all
close all
x=[3,11,7,0,-1,4,2];nx=[-3:3];
[y,ny]=dichchuyen_tinhieu(x,nx,2);
w=randn(1,length(y));nw=ny;
[y,ny]=cong_2tinhieu(y,ny,w,nw);
[x,nx]=gap_tinhieu(x,nx);[rxy,nrxy]=conv_m(y,ny,x,nx);
subplot(1,1,1),subplot(2,1,1);stem(nrxy,rxy);
axis([-5,10,-50,250]);xlabel('lag variable l');
ylabel('rxy');title('Crosscorrelation: noise sequece l')