E=sum(x*x')
E=231