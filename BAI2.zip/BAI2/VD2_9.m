xn=[1 2 3];
hn=[3 2 1];
yn= conv(hn,xn)
yn=conv(hn,xn)