k=-10:10;
xk=exp(-1*(abs(k)));
stem(k,xk)