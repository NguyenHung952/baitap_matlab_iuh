clear all
close all
n=[-5:5];
x=2*ham_xung(-2,-5,5) - ham_xung(4,-5,5);
subplot(1,2,1); stem(n,x); title('Sequence in Problem 2.1a')
stem(n,x);title('Sequence in Problem 2.1a')
xlabel('n');ylabel('x(n)');