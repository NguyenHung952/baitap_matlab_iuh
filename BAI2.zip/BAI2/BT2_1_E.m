n=[-200:200]; x=5*[cos(0.49*pi*n)+cos(0.51*pi*n)];
figure; subplot(1,2,1); stem(n,x); title('Squence in Problem 2.1E')
xlabel('n'); ylabel('x(n)');