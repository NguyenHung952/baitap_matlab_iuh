% Định nghĩa chuỗi x(n)
x = [1, 2, 3, 4, 5];

% Số điểm lấy mẫu trong miền tần số
N = 1024;

% Tính DTFT
X = fft(x, N);

% Tạo vector tần số
omega = linspace(0, 2*pi, N);

% Vẽ đồ thị biên độ và pha của DTFT
figure;
subplot(2,1,1);
plot(omega, abs(X));
title('Biên độ của DTFT');
xlabel('\omega');
ylabel('|X(\omega)|');

subplot(2,1,2);
plot(omega, angle(X));
title('Pha của DTFT');
xlabel('\omega');
ylabel('\angle X(\omega)');