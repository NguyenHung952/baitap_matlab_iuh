% Tạo vector tần số từ 0 đến pi với 501 điểm
w = [0:1:500]*pi/500; % ([0, pi])

% Tính toán hàm X(w)
X = exp(j*w) ./ (exp(j*w) - 0.5*ones(1,501));

%Trong đoạn mã này:

%w là một vector chứa các giá trị tần số từ ( 0 ) đến ( \pi ) với 501 điểm.
%X là hàm được tính bằng cách lấy exp(j*w) chia cho (exp(j*w) - 0.5*ones(1,501)).