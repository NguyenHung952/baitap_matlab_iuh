% Định nghĩa tín hiệu x[n] = 0.5^n * u[n]
n = 0:50; % Chọn khoảng n từ 0 đến 50
x = (0.5).^n; % Tín hiệu x[n]

% Định nghĩa tần số omega từ -pi đến pi
omega = linspace(-pi, pi, 1000);

% Tính DTFT của x[n]
X = x * exp(-1j * n' * omega);

% Vẽ đồ thị biên độ và pha của DTFT
figure;
subplot(2,1,1);
plot(omega, abs(X));
title('Biên độ của DTFT');
xlabel('\omega');
ylabel('|X(\omega)|');

subplot(2,1,2);
plot(omega, angle(X));
title('Pha của DTFT');
xlabel('\omega');
ylabel('\angle X(\omega)');