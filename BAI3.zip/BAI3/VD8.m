clc;clear all;close all;
n=0:100;x=cos(pi*n/2);
k=-100:100;w=(pi/100)*k;
X=x*(exp(-j*pi/100)).^(n'*k); 
y=exp(j*pi*n/4).*x;
Y=y*(exp(-j*pi/100)).^(n'*k);

subplot(2,2,1);
plot(w/pi, abs(X)); grid; axis([-1,1,0,60])
xlabel('frequency in pi units');ylabel('|X|'); title('Magnitude of X');

subplot(2,2,2);
plot(w/pi, angle(X)/pi); grid; axis([-1,1,-1,1])
xlabel('frequency in pi units'); ylabel('radians/pi'); title('Angle of X');

subplot(2,2,3);
plot(w/pi, abs(Y)); grid; axis([-1,1,0,60])
xlabel('frequency in pi units'); ylabel('|Y|'); title('Magnitude of y');

subplot(2,2,4);
plot(w/pi, angle(Y)/pi); grid; axis([-1,1,-1,1])
xlabel('frequency in pi units'); ylabel('radians/pi'); title('Angle of y');

error=sum(abs(X(1:end-25)-Y(26:end)))/length(X(1:end-25));

