%BT3: Tạo tín hiệu rời rạc từ 2 tín hiệu 2sinf0t và 5cosf1t lần lượt có tấn
%số f0=2,f1=4,fs=24(các đơn vị tần số giả định là kHz)
%a)Tính phổ FFT cho dữ liệu rời rạc trên với chiều dài dữ liệu là 32 mẫu,
%xuất dạng sóng thời gian và phổ FFT tương ứng
%b)Tính phổ DTFT cho chuỗi rời rạc trên, biểu diễn phổ trong khoảng (0 đến
%pi)
%c)So sánh phổ trong câu a và b, cho biết tần số số (Ω) của sóng cos có giá
%trị bằng bao nhiêu rad và có giá trị bằng bao nhiêu trong phổ FFT

%a)
% Parameters
f0 = 2; % kHz
f1 = 4; % kHz
fs = 24; % kHz
N = 32; % Number of samples
t = (0:N-1)/fs; % Time vector

% Signals
x1 = 2 * sin(2 * pi * f0 * t);
x2 = 5 * cos(2 * pi * f1 * t);
x = x1 + x2;

% FFT
X = fft(x, N);
f = (0:N-1) * (fs/N); % Frequency vector

% Plot time-domain waveform
figure;
subplot(2,1,1);
stem(t, x);
title('Time-Domain Waveform');
xlabel('Time (ms)');
ylabel('Amplitude');

% Plot FFT spectrum
subplot(2,1,2);
stem(f, abs(X));
title('FFT Spectrum');
xlabel('Frequency (kHz)');
ylabel('Magnitude');

%b)
% DTFT
omega = linspace(0, pi, 1024);
X_dtft = zeros(1, 1024);
for k = 1:1024
    X_dtft(k) = sum(x .* exp(-1j * omega(k) * (0:N-1)));
end

% Plot DTFT spectrum
figure;
subplot(2,1,1);
plot(omega, abs(X_dtft));
title('DTFT Magnitude Spectrum');
xlabel('Frequency (rad/sample)');
ylabel('|X(e^{j\omega})|');

subplot(2,1,2);
plot(omega, angle(X_dtft));
title('DTFT Phase Spectrum');
xlabel('Frequency (rad/sample)');
ylabel('∠X(e^{j\omega})');

%c)
%Tần số rời rạc (Ω) của sóng cosin là 3 rad/mẫu. Trong phổ FFT, giá trị tần số tương ứng là khoảng 5,33 kHz.