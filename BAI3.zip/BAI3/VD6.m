clc;clear all;close all;

% Định nghĩa các giá trị của n và x(n)
n = -10:10;
x = (-0.9).^n;

% Định nghĩa các giá trị của k và w
k = -200:200;
w = (pi/100)*k;

% Tính toán DTFT. Tổng hữu hạn của các giá trị 
X = x * (exp(-j*pi/100)).^(n' * k);

% Tính toán các thành phần biên độ, pha, thực và ảo của X(w)
magX = abs(X);
angX = angle(X);


subplot(2,1,1);
plot(w/pi, magX); grid; axis([-2,2,0,15])
xlabel('frequency in pi units');ylabel('|X|'); title('Magnitude Part');

subplot(2,1,2);
plot(w/pi, angX/pi); grid; axis([-2,2,-1,1])
xlabel('frequency in pi units'); ylabel('radians/pi'); title('Angle Part');

k=0:200;X_reversed=conj(X(201-k));%X(201-k)
X_conjugate=X(201+k);%X*(201+k)
error=norm(X_reversed - X_conjugate);
%disp(['Norm of the error:',num2str(error)]);_
