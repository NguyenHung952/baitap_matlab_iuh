%%BT2: Tính DTFT và vẽ phổ biên độ phổ pha tương ứng cho các tín hiệu rời
%rạc sau trong khoảng 0<=w<=pi:
%a) x(n)=2*[(0.5)^n]*u(n+2)
%b) x(n)=[(0.6)^|n|]*[u(n+10)-u(n-11)]
%c) x(n)=[n*(0.9)^n]*u(n+3)
%d) x(n)=(n+3)*[(0.8)^(n-1)]*u(n-2)
%e) x(n)=4*[(-0.7)^n]*cos(0.25*pi*n)*u(n)

%a)
n = 0:100; % Adjust the range as needed
x_a = 2 * (0.5).^n .* heaviside(n+2);
X_a = fft(x_a, 1024);
f = linspace(0, pi, 512);

figure;
subplot(2,1,1);
plot(f, abs(X_a(1:512)));
title('Magnitude Spectrum of x_a(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_a(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_a(1:512)));
title('Phase Spectrum of x_a(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_a(e^{j\omega})');

%b)
n = -10:10;
x_b = (0.6).^abs(n) .* (heaviside(n+10) - heaviside(n-11));
X_b = fft(x_b, 1024);
f = linspace(0, pi, 512);

figure;
subplot(2,1,1);
plot(f, abs(X_b(1:512)));
title('Magnitude Spectrum of x_b(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_b(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_b(1:512)));
title('Phase Spectrum of x_b(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_b(e^{j\omega})');

%c)
n = 0:100; % Adjust the range as needed
x_c = n .* (0.9).^n .* heaviside(n+3);
X_c = fft(x_c, 1024);
f = linspace(0, pi, 512);

figure;
subplot(2,1,1);
plot(f, abs(X_c(1:512)));
title('Magnitude Spectrum of x_c(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_c(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_c(1:512)));
title('Phase Spectrum of x_c(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_c(e^{j\omega})');

%d)
n = 0:100; % Adjust the range as needed
x_d = (n+3) .* (0.8).^(n-1) .* heaviside(n-2);
X_d = fft(x_d, 1024);
f = linspace(0, pi, 512);

figure;
subplot(2,1,1);
plot(f, abs(X_d(1:512)));
title('Magnitude Spectrum of x_d(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_d(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_d(1:512)));
title('Phase Spectrum of x_d(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_d(e^{j\omega})');

%e)
n = 0:100; % Adjust the range as needed
x_e = 4 * (-0.7).^n .* cos(0.25*pi*n) .* heaviside(n);
X_e = fft(x_e, 1024);
f = linspace(0, pi, 512);

figure;
subplot(2,1,1);
plot(f, abs(X_e(1:512)));
title('Magnitude Spectrum of x_e(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_e(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_e(1:512)));
title('Phase Spectrum of x_e(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_e(e^{j\omega})');