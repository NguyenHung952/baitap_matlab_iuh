%Để thay đổi biểu diễn ( w ) từ (-2\pi) đến ( 0 ) với 200 điểm, bạn có thể điều chỉnh đoạn mã MATLAB như sau:
clc; clear all; close all;
% Định nghĩa các giá trị của n và x(n)
n = -1:3;
x = 1:5;

% Định nghĩa các giá trị của k và w
k = 0:199;
w = linspace(-2*pi, 0, 200);

% Tính toán DTFT. Tổng hữu hạn của các giá trị 
X = x * (exp(-j * w)).^(n' * k);

% Tính toán các thành phần biên độ, pha, thực và ảo của X(w)
magX = abs(X);
angX = angle(X);
realX = real(X);
imagX = imag(X);

% Vẽ đồ thị biên độ, pha, thực và ảo của X(w)
figure;
subplot(2,2,1);
plot(w, magX); grid;
xlabel('frequency in pi units'); title('Magnitude Part');

subplot(2,2,2);
plot(w, angX); grid;
xlabel('frequency in pi units'); title('Angle Part');

subplot(2,2,3);
plot(w, realX); grid;
xlabel('frequency in pi units'); title('Real Part');

subplot(2,2,4);
plot(w, imagX); grid;
xlabel('frequency in pi units'); title('Imaginary Part');