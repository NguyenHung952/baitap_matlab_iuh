
% Tạo vector tần số từ -pi đến pi với 101 điểm
w = linspace(-pi, pi, 101);

% Tính toán hàm X(w)
X = exp(j*w) ./ (exp(j*w) - 0.5*ones(1,101));

% Vẽ đồ thị biên độ và pha của X(w)
figure;
subplot(2,1,1);
plot(w, abs(X));
title('Biên độ của X(\omega)');
xlabel('\omega');
ylabel('|X(\omega)|');

subplot(2,1,2);
plot(w, angle(X));
title('Pha của X(\omega)');
xlabel('\omega');
ylabel('\angle X(\omega)');