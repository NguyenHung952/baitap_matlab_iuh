%BT1: Tính DTFT và vẽ phổ biên độ phổ pha tương ứng cho các tín hiệu rời
%rạc sau:
%a) x(n)=(0.6)^|n|[u(n+10)-u(n-11)]
%b) x(n)=n(0.9)^n[u(n)-u(n-21)]
%c) x(n)=[cos(0.5*pi*n)+jsin(0.5*pi*n)][u(n)-u(n-51)]
%d) x(n)={4,3,2,1,1,2,3,4}

%a)
n = -10:10;
x_a = (0.6).^abs(n) .* (heaviside(n+10) - heaviside(n-11));
X_a = fftshift(fft(x_a, 1024));
f = linspace(-pi, pi, 1024);

figure;
subplot(2,1,1);
plot(f, abs(X_a));
title('Magnitude Spectrum of x_a(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_a(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_a));
title('Phase Spectrum of x_a(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_a(e^{j\omega})');

%b)
n = 0:20;
x_b = n .* (0.9).^n .* (heaviside(n) - heaviside(n-21));
X_b = fftshift(fft(x_b, 1024));
f = linspace(-pi, pi, 1024);

figure;
subplot(2,1,1);
plot(f, abs(X_b));
title('Magnitude Spectrum of x_b(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_b(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_b));
title('Phase Spectrum of x_b(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_b(e^{j\omega})');

%c)
n = 0:50;
x_c = (cos(0.5*pi*n) + 1j*sin(0.5*pi*n)) .* (heaviside(n) - heaviside(n-51));
X_c = fftshift(fft(x_c, 1024));
f = linspace(-pi, pi, 1024);

figure;
subplot(2,1,1);
plot(f, abs(X_c));
title('Magnitude Spectrum of x_c(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_c(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_c));
title('Phase Spectrum of x_c(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_c(e^{j\omega})');

%d)
x_d = [4, 3, 2, 1, 1, 2, 3, 4];
X_d = fftshift(fft(x_d, 1024));
f = linspace(-pi, pi, 1024);

figure;
subplot(2,1,1);
plot(f, abs(X_d));
title('Magnitude Spectrum of x_d(n)');
xlabel('Frequency (rad/sample)');
ylabel('|X_d(e^{j\omega})|');

subplot(2,1,2);
plot(f, angle(X_d));
title('Phase Spectrum of x_d(n)');
xlabel('Frequency (rad/sample)');
ylabel('∠X_d(e^{j\omega})');