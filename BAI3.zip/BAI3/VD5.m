clc;clear all;close all;

% Định nghĩa các giá trị của n và x(n)
n = 0:10;
x = (0.9*exp(j*pi/3)).^n;

% Định nghĩa các giá trị của k và w
k = -200:200;
w = (pi/100)*k;

% Tính toán DTFT. Tổng hữu hạn của các giá trị 
X = x * (exp(-j*pi/100)).^(n' * k);

% Tính toán các thành phần biên độ, pha, thực và ảo của X(w)
magX = abs(X);
angX = angle(X);


subplot(2,1,1);
plot(w/pi, magX); grid;
xlabel('frequency in pi units');ylabel('|X|'); title('Magnitude Part');

subplot(2,1,2);
plot(w/pi, angX/pi); grid;
xlabel('frequency in pi units'); ylabel('radians/pi'); title('Angle Part');
