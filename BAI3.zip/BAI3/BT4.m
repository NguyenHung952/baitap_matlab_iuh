%BT4: Tạo tín hiệu rời rạc từ 2 tín hiệu 4cosf0t và 2sinf1t lần lượt có tấn
%số f0=4,f1=8,fs=32(các đơn vị tần số giả định là kHz)
%a)Tính phổ FFT cho dữ liệu rời rạc trên với chiều dài dữ liệu là 62 mẫu,
%xuất dạng sóng thời gian và phổ FFT tương ứng
%b)Tính phổ FFT cho dữ liệu rời rạc trên với chiều dài dữ liệu là 68 mẫu,
%xuất dạng sóng thời gian và phổ FFT tương ứng, nhận xét kết quả
%c)Thay đổi kích thước FFT lớn hơn FFT mặc định với dữ liệu câu a và nhận
%xét kết quả
%c)Thay đổi kích thước FFT nhỏ hơn FFT mặc định với dữ liệu câu a và nhận
%xét kết quả

%a)
% Parameters
f0 = 4; % kHz
f1 = 8; % kHz
fs = 32; % kHz
N = 62; % Number of samples
t = (0:N-1)/fs; % Time vector

% Signals
x1 = 4 * cos(2 * pi * f0 * t);
x2 = 2 * sin(2 * pi * f1 * t);
x = x1 + x2;

% FFT
X = fft(x, N);
f = (0:N-1) * (fs/N); % Frequency vector

% Plot time-domain waveform
figure;
subplot(2,1,1);
stem(t, x);
title('Time-Domain Waveform (62 samples)');
xlabel('Time (ms)');
ylabel('Amplitude');

% Plot FFT spectrum
subplot(2,1,2);
stem(f, abs(X));
title('FFT Spectrum (62 samples)');
xlabel('Frequency (kHz)');
ylabel('Magnitude');

%b)
% Parameters
N = 68; % Number of samples
t = (0:N-1)/fs; % Time vector

% Signals
x1 = 4 * cos(2 * pi * f0 * t);
x2 = 2 * sin(2 * pi * f1 * t);
x = x1 + x2;

% FFT
X = fft(x, N);
f = (0:N-1) * (fs/N); % Frequency vector

% Plot time-domain waveform
figure;
subplot(2,1,1);
stem(t, x);
title('Time-Domain Waveform (68 samples)');
xlabel('Time (ms)');
ylabel('Amplitude');

% Plot FFT spectrum
subplot(2,1,2);
stem(f, abs(X));
title('FFT Spectrum (68 samples)');
xlabel('Frequency (kHz)');
ylabel('Magnitude');

%c)
% Parameters
N = 62; % Number of samples
fft_size = 128; % Larger FFT size
t = (0:N-1)/fs; % Time vector

% Signals
x1 = 4 * cos(2 * pi * f0 * t);
x2 = 2 * sin(2 * pi * f1 * t);
x = x1 + x2;

% FFT
X = fft(x, fft_size);
f = (0:fft_size-1) * (fs/fft_size); % Frequency vector

% Plot FFT spectrum
figure;
stem(f, abs(X));
title('FFT Spectrum with Larger FFT Size (128)');
xlabel('Frequency (kHz)');
ylabel('Magnitude');

%d)
% Parameters
N = 62; % Number of samples
fft_size = 32; % Smaller FFT size
t = (0:N-1)/fs; % Time vector

% Signals
x1 = 4 * cos(2 * pi * f0 * t);
x2 = 2 * sin(2 * pi * f1 * t);
x = x1 + x2;

% FFT
X = fft(x, fft_size);
f = (0:fft_size-1) * (fs/fft_size); % Frequency vector

% Plot FFT spectrum
figure;
stem(f, abs(X));
title('FFT Spectrum with Smaller FFT Size (32)');
xlabel('Frequency (kHz)');
ylabel('Magnitude');