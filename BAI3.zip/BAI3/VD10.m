clc;clear all;close all;
N=100;
n=0:1:19;
a=cos(2*pi*n*5/N);
figure();subplot(2,1,1);
stem(n,a);
xlabel('Time Index');
ylabel('Amplitude');
title('Orginal Discrete Signal');
b=fft(a); subplot(2,1,2);
stem(n,abs(b));
xlim([min(n) max(n)+1]);
xlabel('Frequency Index');
ylabel('Magnitude');
title('Magnitude of FFT (Default Length)');

c=fft(a,200);figure();stem(abs(c));
xlabel('Frequency Index');
ylabel('Magnitude');
title('Magnitude of FFT(Larger Length)');

n=0:1:99;
a=cos(2*pi*n*5/N);
subplot(1,1,1,'Position',[0.1,0.2,0.85,0.65]);
stem(n,a,'blue','LineWidth',1,'MarkerFaceColor','b');
xlabel('Time Index'); ylabel('Amplitude');
title('Original Discrete Signal'); b=fft(a);
subplot(1,1,1,'Position',[0.1,0.2,0.85,0.65]);
stem(n,abs(b),'r','LineWidth',1,'MarkerFaceColor','r');
xlim([min(n) max(n)+1]);
xlabel('Frequency Index');
ylabel('Magnitude');
title('Magnitude of FFT (Default Length,N_F_F_T=20)')