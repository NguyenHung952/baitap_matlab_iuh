clc;clear all;close all;
N=100;
N1=100/5;
T=[2 10 5.5]; Np=[2*N1 10*N1 5.5*N1];
for i=1:3
    n=0:1:Np(i)-1;
    a=cos(2*pi*n*5/N);
    subplot(1,1,1,'Position',[0.1,0.2,0.85,0.65]);
    stem(n,a,'blue','LineWidth',1,'MarkerFaceColor','b');
    xlabel('Time Index');
    ylabel('Amplitude');
    title(['Discrete Signal, Number of Cyclic=',num2str(T(i))]);
    
    b=fft(a);
    subplot(1,1,1,'Position',[0.1,0.2,0.85,0.65]);
    stem(n,abs(b),'r','LineWidth',1,'MarkerFaceColor','r');
    xlim([min(n) max(n)+1]);
    xlabel('Frequency Index'); ylabel('Magnitude');
    title(['Magnitude of FFT Number of Cyclic=',num2str(T(i))]);
end