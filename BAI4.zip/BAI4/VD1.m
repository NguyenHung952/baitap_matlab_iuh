clc; clear all; close all;

% Define the parameters
M = 45; % Filter length
wc = 0.3 * pi; % Cutoff frequency
a = 0.5; % Arbitrary phase factor
n = 0:(M-1);

% Calculate the ideal impulse response
alpha = (M - 1) / 2;
m = n - alpha;
hd = (wc / pi) * sinc((wc / pi) * m) .* exp(-1j * a * m); % Using sinc function

% Define the window (e.g., Hamming window)
window = hamming(M)';

% Apply the window to the ideal impulse response
h = real(hd .* window);

% Frequency response
[H, w] = freqz(h, 1, 1024);
H_dB = 20 * log10(abs(H));

% Plotting results
subplot(2, 1, 1);
stem(n, h, 'black');
title('Impulse Response of FIR Low-pass Filter');
xlabel('n');
ylabel('h(n)');
grid on;

subplot(2, 1, 2);
plot(w / pi, H_dB, 'black');
title('Frequency Response of FIR Low-pass Filter');
xlabel('Frequency (\times\pi rad/sample)');
ylabel('Magnitude (dB)');
grid on;
axis([0 1 -100 10]);
