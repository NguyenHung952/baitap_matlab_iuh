clc; clear all; close all;

M = 45; 
As = 60; 
n = [0:1:M-1];

% Calculate beta for the Kaiser window
beta = 0.1102 * (As - 8.7);

% Generate the Kaiser window
w_kai = kaiser(M, beta);

% Cutoff frequencies
wcl = pi / 3; % Lower cutoff frequency
wc2 = 2 * pi / 3; % Upper cutoff frequency

% Ideal bandpass filter impulse response
hd = ideal_lp(wc2, M) - ideal_lp(wcl, M);

% Apply the window to the ideal impulse response
h = hd .* w_kai; 

% Frequency response
[db, mag, pha, grd, w] = freqz_m(h, [1]);

% Plotting results
subplot(2, 2, 1);
stem(n, hd, 'black');
title('Ideal Impulse Response');
xlabel('n');
ylabel('hd(n)');
axis([0 M -0.2 0.8]);

subplot(2, 2, 2);
stem(n, w_kai, 'black');
title('Kaiser Window');
axis([-1 M 0 1.1]);
xlabel('n');
ylabel('w(n)');

subplot(2, 2, 3);
stem(n, h, 'black');
title('Actual Impulse Response');
axis([-1 M -0.2 0.8]);
xlabel('n');
ylabel('h(n)');

subplot(2, 2, 4);
plot(w / pi, db, 'black');
title('Magnitude Response in dB');
axis([0 1 -80 10]);
xlabel('frequency in pi units');
ylabel('Decibels');
grid;
