
clc; clear all; close all;

% Define the frequencies
w_s1 = 0.2 * pi; % First stopband edge
w_p1 = 0.35 * pi; % First passband edge
w_s2 = 0.8 * pi; % Second stopband edge
w_p2 = 0.65 * pi; % Second passband edge

% Ensure w_s1 < w_p1 < w_s2 < w_p2
if ~(w_s1 < w_p1 && w_p1 < w_p2 && w_p2 < w_s2)
    error('Frequencies must satisfy w_s1 < w_p1 < w_p2 < w_s2');
end

% Filter specifications
As = 60; % Stopband attenuation

% Calculate transition width and ensure it is positive
transition_width1 = w_p1 - w_s1;
transition_width2 = w_s2 - w_p2;
if transition_width1 <= 0 || transition_width2 <= 0
    error('Transition width must be positive. Check the frequency values.');
end
transition_width = min(transition_width1, transition_width2); % Transition width

% Filter order
M_order = ceil(11 * pi / transition_width) + 1;
if mod(M_order, 2) == 0
    M_order = M_order + 1; % Ensure M_order is odd
end

% Print M_order to check its value
fprintf('M_order = %d\n', M_order);

% Validate M_order
if M_order <= 0
    error('M_order must be a positive integer');
end

% Index for the filter
n_sequence = 0:1:M_order - 1;

% Cutoff frequencies
w_c1 = (w_s1 + w_p1) / 2; % First cutoff frequency
w_c2 = (w_p2 + w_s2) / 2; % Second cutoff frequency

% Ideal band-pass filter impulse response
h_ideal = ideal_lp(w_c2, M_order) - ideal_lp(w_c1, M_order);

% Blackman window
window_blackman = blackman(M_order);
h_actual = h_ideal .* window_blackman; % Actual filter impulse response

% Frequency response
[db_response, mag_response, pha_response, grd_response, w_response] = freqz_m(h_actual, [1]);
delta_w_response = 2 * pi / 1000;
ripple_passband = -min(db_response(w_p1 / delta_w_response + 1:1:w_p2 / delta_w_response)); % Passband ripple
attenuation_stopband = -round(max(db_response(w_s2 / delta_w_response + 1:1:501))); % Stopband attenuation

% Plotting results
subplot(2, 2, 1);
stem(n_sequence, h_ideal, 'black');
title('Ideal Impulse Response');
xlabel('n');
ylabel('h_d(n)');
axis([0 M_order -0.4 0.5]);

subplot(2, 2, 2);
stem(n_sequence, window_blackman, 'black');
title('Blackman Window');
axis([0 M_order 0 1.1]);
xlabel('n');
ylabel('w_(n)');

subplot(2, 2, 3);
stem(n_sequence, h_actual, 'black');
title('Actual Impulse Response');
axis([0 M_order -0.4 0.5]);
xlabel('n');
ylabel('h_(n)');

subplot(2, 2, 4);
plot(w_response / pi, db_response, 'black');
title('Magnitude Response - dB');
grid on;
axis([0 1 -150 10]);
xlabel('frequency - pi units');
ylabel('Decibels');
grid;
