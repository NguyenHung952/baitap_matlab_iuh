clc; clear ; close all;

% Define the frequencies
w_s = 0.4 * pi; % Stopband edge
w_p = 0.6 * pi; % Passband edge

% Filter specifications
As = 50; % Stopband attenuation in dB
Rp = 0.0004; % Passband ripple in dB

% Calculate transition width
transition_width = abs(w_p - w_s);

% Calculate filter order
M_order = ceil(11 * pi / transition_width) + 1;
if mod(M_order, 2) == 0
    M_order = M_order + 1; % Ensure M_order is odd
end

% Print M_order to check its value
fprintf('M_order = %d\n', M_order);

% Validate M_order
if M_order <= 0
    error('M_order must be a positive integer');
end

% Index for the filter
n_sequence = 0:1:M_order - 1;

% Cutoff frequency
wc = (w_s + w_p) / 2;

% Ideal low-pass filter impulse response
hd = ideal_lp(wc, M_order);

% Hann window
window_hann = hann(M_order)';
h = hd .* window_hann; % Actual filter impulse response

% Frequency response
[H, w] = freqz(h, 1, 1024);
H_dB = 20 * log10(abs(H));

% Plotting results
subplot(2, 2, 1);
stem(n_sequence, hd, 'black');
title('Ideal Impulse Response');
xlabel('n');
ylabel('h_d(n)');
axis([0 M_order -0.4 0.5]);

subplot(2, 2, 2);
stem(n_sequence, window_hann, 'black');
title('Hann Window');
axis([0 M_order 0 1.1]);
xlabel('n');
ylabel('w(n)');

subplot(2, 2, 3);
stem(n_sequence, h, 'black');
title('Actual Impulse Response');
axis([0 M_order -0.4 0.5]);
xlabel('n');
ylabel('h(n)');

subplot(2, 2, 4);
plot(w / pi, H_dB, 'black');
title('Magnitude Response - dB');
grid on;
axis([0 1 -80 10]);
xlabel('Frequency (\times\pi rad/sample)');
ylabel('Magnitude (dB)');
