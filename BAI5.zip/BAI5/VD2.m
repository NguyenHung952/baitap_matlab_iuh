clc; clear all; close all;

% Define the specifications
Wp = 0.2 * pi;
Ws = 0.3 * pi;
Rp = 7;
As = 16;
Ripple = 10^(-Rp/20);
Attn = 10^(-As/20);

% Normalize frequencies (analog)
Wp_n = tan(Wp / 2);
Ws_n = tan(Ws / 2);

% Design Butterworth filter
[n, Wn] = buttord(Wp_n, Ws_n, Rp, As);
[b, a] = butter(n, Wn, 's');

% Calculate the frequency response
[H, omega] = freqs(b, a, linspace(0, pi, 1000));

% Plot the frequency response
figure;
subplot(2,1,1);
plot(omega / pi, 20*log10(abs(H)), 'black');
title('Frequency Response of Butterworth Filter');
xlabel('Normalized Frequency (\times\pi rad/s)');
ylabel('Magnitude (dB)');
grid on;

% Manually calculate the impulse response
dt = 0.01; % Time step
t = 0:dt:5; % Time vector
impulse_input = zeros(size(t));
impulse_input(1) = 1 / dt; % Impulse input
impulse_output = filter(b, a, impulse_input);

% Plot the impulse response
subplot(2,1,2);
plot(t, impulse_output, 'black');
title('Impulse Response of Butterworth Filter');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;
