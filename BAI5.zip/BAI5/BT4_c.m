clc; clear; close all;

% Khai báo số mẫu của bộ lọc FIR
N = 51; % Độ dài bộ lọc FIR
fc = 3000; % Tần số cắt (Hz)
fs = 48000; % Tần số lấy mẫu (Hz)

% Tạo hệ số bộ lọc FIR thông thấp bằng cửa sổ Hamming
h = fir1(N-1, 2*fc/fs, 'low', hamming(N));

% Hiển thị hệ số lọc
figure;
stem(h);
title('Hệ số bộ lọc FIR');
xlabel('Mẫu (n)');
ylabel('h(n)');

% Tạo tín hiệu đầu vào - xung đơn (impulse)
x = [1, zeros(1, 199)]; % Tín hiệu có một xung tại n=0

% Áp dụng bộ lọc FIR bằng phép tích chập
y = conv(x, h);

% Hiển thị đáp ứng xung
figure;
plot(y, 'b', 'LineWidth', 1.5);
title('Đáp ứng xung của bộ lọc FIR');
xlabel('Mẫu (n)');
ylabel('y(n)');
grid on;

% Kiểm tra đáp ứng tần số của bộ lọc
H = fft(h, 1024); % FFT để kiểm tra tần số
f = linspace(0, fs/2, 512); % Trục tần số (Hz)

figure;
plot(f, abs(H(1:512)), 'r', 'LineWidth', 1.5);
title('Đáp ứng biên độ của bộ lọc FIR');
xlabel('Tần số (Hz)');
ylabel('|H(f)|');
grid on;


% Tải file âm thanh
load handel.mat; % Tải file âm thanh handel mặc định
audio = y'; % Chuyển thành vector hàng
audio = audio(1:8192); % Sử dụng một đoạn ngắn của âm thanh để đơn giản
audio = audio / max(abs(audio)); % Chuẩn hóa âm thanh

% Tạo nhiễu sin
t = (0:length(audio)-1)/fs;
noise = sin(2*pi*f1*t) + sin(2*pi*f2*t) + sin(2*pi*f3*t);

% Thêm nhiễu vào âm thanh
noisy_audio = audio + noise;

% Áp dụng bộ lọc Notch
filtered_audio = filter(b, a, noisy_audio);

% Vẽ các dạng sóng
figure;
subplot(3, 1, 1);
plot(t, audio);
title('Tín hiệu âm thanh gốc');
xlabel('Thời gian (s)');
ylabel('Biên độ');

subplot(3, 1, 2);
plot(t, noisy_audio);
title('Tín hiệu âm thanh bị nhiễu');
xlabel('Thời gian (s)');
ylabel('Biên độ');

subplot(3, 1, 3);
plot(t, filtered_audio);
title('Tín hiệu âm thanh đã lọc');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Phát âm thanh đã lọc
sound(filtered_audio, fs);
