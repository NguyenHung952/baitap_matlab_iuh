clc; clear all; close all;

fs = 8000; % Tần số lấy mẫu
f1 = 1000; % Tần số nhiễu 1 kHz
f2 = 2000; % Tần số nhiễu 2 kHz
f3 = 3000; % Tần số nhiễu 3 kHz

% Tần số đã chuẩn hóa
w1 = 2*pi*f1/fs;
w2 = 2*pi*f2/fs;
w3 = 2*pi*f3/fs;

% Tham số lọc Notch
r = 0.99; % Bán kính cực của bộ lọc Notch, gần 1 để có notch hẹp

% Bộ lọc Notch 1 kHz
b1 = [1 -2*cos(w1) 1];
a1 = [1 -2*r*cos(w1) r^2];

% Bộ lọc Notch 2 kHz
b2 = [1 -2*cos(w2) 1];
a2 = [1 -2*r*cos(w2) r^2];

% Bộ lọc Notch 3 kHz
b3 = [1 -2*cos(w3) 1];
a3 = [1 -2*r*cos(w3) r^2];

% Bộ lọc tổng thể bằng cách nối tiếp các bộ lọc
b = conv(conv(b1, b2), b3);
a = conv(conv(a1, a2), a3);

% Vẽ đáp ứng tần số
[H, f] = freqz(b, a, 1024, fs);
figure;
plot(f, 20*log10(abs(H)), 'black');
title('Đáp ứng tần số của bộ lọc Notch');
xlabel('Tần số (Hz)');
ylabel('Biên độ (dB)');
grid on;
