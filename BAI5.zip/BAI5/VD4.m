clc; clear; close all;

% Thông số bộ lọc
Wp = 0.25 * pi; % Tần số passband
Ws = 0.4 * pi; % Tần số stopband
Rp = 1; % Ripple ở passband (dB)
As = 30; % Suy giảm ở stopband (dB)

% Chuyển đổi tần số số sang analog (bằng bilinear transform)
Ts = 1; % Chu kỳ lấy mẫu (giả sử bằng 1 để đơn giản)
Omega_p = 2 * tan(Wp / 2);
Omega_s = 2 * tan(Ws / 2);

% Tính toán thứ tự và tần số cắt của bộ lọc Butterworth
[N, Omegac] = buttord(Omega_p, Omega_s, Rp, As, 's');
[C, D] = butter(N, Omegac, 's');

% Chuyển đổi bộ lọc tương tự sang số bằng phương pháp impinvar
[B, A] = impinvar(C, D, 1 / Ts);

% Hiển thị các hệ số của bộ lọc số
disp('Hệ số của bộ lọc số:');
disp('B:'); disp(B);
disp('A:'); disp(A);

% Đáp ứng tần số của bộ lọc số
[H, omega] = freqz(B, A, linspace(0, pi, 1000));

% Đáp ứng xung của bộ lọc số
impulse_input = [1; zeros(49, 1)]; % Đầu vào xung đơn vị
impulse_output = filter(B, A, impulse_input);

% Vẽ đáp ứng tần số
figure;
subplot(2, 1, 1);
plot(omega / pi, 20*log10(abs(H)), 'black');
title('Đáp ứng tần số của Butterworth Filter');
xlabel('Tần số (x π rad/sample)');
ylabel('Biên độ (dB)');
grid on;

% Vẽ đáp ứng xung
subplot(2, 1, 2);
stem(impulse_output, 'black');
title('Đáp ứng xung của Butterworth Filter');
xlabel('Mẫu');
ylabel('Biên độ');
grid on;
