% Chuẩn hóa độ lợi
H_max = max(abs(H));
b = b / H_max;

% Vẽ đáp ứng tần số
[H, f] = freqz(b, a, 1024, fs);
figure;
plot(f, 20*log10(abs(H)), 'black');
title('Đáp ứng biên độ của bộ lọc Notch đã chuẩn hóa');
xlabel('Tần số (Hz)');
ylabel('Biên độ (dB)');
grid on;
