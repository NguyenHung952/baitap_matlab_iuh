clc; clear; close all;

% Định nghĩa tham số
omega_0 = pi / 2;
r_values = [0.7, 0.9, 0.99];
fs = 1; % Tần số lấy mẫu

figure;
for i = 1:length(r_values)
    r = r_values(i);
    
    % Định nghĩa bộ lọc với một null tại w = pi/2
    b = [1, -2*cos(omega_0), 1]; % Hệ số b
    a = [1, -2*r*cos(omega_0), r^2]; % Hệ số a với hai cực tại r*exp(+-j*omega_0)
    
    % Đáp ứng tần số
    [H, f] = freqz(b, a, 1024, fs);
    
    % Vẽ đáp ứng tần số
    subplot(3, 1, i);
    plot(f/pi, 20*log10(abs(H)), 'black');
    title(['Đáp ứng tần số với r = ', num2str(r)]);
    xlabel('Tần số (x π rad/sample)');
    ylabel('Biên độ (dB)');
    grid on;
    
    % Tính băng thông 3 dB và tần số cộng hưởng
    [H_max, idx_max] = max(abs(H));
    f_resonant = f(idx_max);
    H_3dB = H_max / sqrt(2); % Mức -3 dB
    idx_3dB_left = find(abs(H(1:idx_max)) <= H_3dB, 1, 'last');
    idx_3dB_right = find(abs(H(idx_max:end)) <= H_3dB, 1, 'first') + idx_max - 1;
    
    BW_3dB = (f(idx_3dB_right) - f(idx_3dB_left)); % Băng thông 3 dB
    
    fprintf('Với r = %.2f:\n', r);
    fprintf('  Tần số cộng hưởng: %.4f π rad/sample\n', f_resonant / pi);
    fprintf('  Băng thông 3 dB: %.4f π rad/sample\n\n', BW_3dB / pi);
end
