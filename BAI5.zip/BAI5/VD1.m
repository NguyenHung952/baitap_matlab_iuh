clc; clear ; close all;

% Define the frequency range
Omega = logspace(-2, 2, 1000); % From 0.01 to 100 rad/s

% Compute the magnitude response
H_a = 1 ./ sqrt(1 + 64 * Omega.^6);

% Plot the magnitude response
figure;
semilogx(Omega, 20*log10(H_a), 'black');
title('Magnitude Response of the Analog Filter');
xlabel('Frequency (rad/s)');
ylabel('Magnitude (dB)');
grid on;

% Define the s variable for symbolic calculation
syms s
H_a_symbolic = 1 / sqrt(1 + 64 * s^6);

% Display the symbolic transfer function
disp('Analog Transfer Function H_a(s):');
disp(H_a_symbolic);
