clc; clear all; close all;

% Đáp ứng xung tương tự
syms t
ha_t = exp(-2*t) * heaviside(t);

% Hàm truyền tương tự
syms s
Ha_s = laplace(ha_t, t, s);
disp('Hàm truyền tương tự H_a(s):');
disp(Ha_s);

% Chuyển đổi bilinear
[b, a] = bilinear([1], [1 2], 1);

% Hiển thị các hệ số của bộ lọc số
disp('Hệ số của bộ lọc số:');
disp('b:'); disp(b);
disp('a:'); disp(a);

% Đáp ứng tần số của bộ lọc số
[H, omega] = freqz(b, a, linspace(0, pi, 1000));

% Đáp ứng xung của bộ lọc số sử dụng impinvar
[B, A] = impinvar(1, [1, 2], 10);

% Đáp ứng tần số của bộ lọc số impinvar
[H_imp, omega_imp] = freqz(B, A, linspace(0, pi, 1000));

% Đáp ứng xung của bộ lọc số
impulse_input = [1; zeros(49, 1)]; % Đầu vào xung đơn vị
impulse_output = filter(B, A, impulse_input);

% Vẽ đáp ứng tần số
figure;
subplot(3, 1, 1);
plot(omega / pi, 20*log10(abs(H)), 'black');
title('Đáp ứng tần số của Butterworth Filter');
xlabel('Tần số (x π rad/sample)');
ylabel('Biên độ (dB)');
grid on;

subplot(3, 1, 2);
plot(omega_imp / pi, 20*log10(abs(H_imp)), 'black');
title('Đáp ứng tần số của Butterworth Filter (impinvar)');
xlabel('Tần số (x π rad/sample)');
ylabel('Biên độ (dB)');
grid on;

% Vẽ đáp ứng xung
subplot(3, 1, 3);
stem(impulse_output, 'black');
title('Đáp ứng xung của Butterworth Filter (impinvar)');
xlabel('Mẫu');
ylabel('Biên độ');
grid on;
